pip install aiogram
pip install terminal_banner
pip install db-sqlite3
pip install logging
