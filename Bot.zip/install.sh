#!/bin/bash
clear
apt install git
apt install python3

python3 install.py
